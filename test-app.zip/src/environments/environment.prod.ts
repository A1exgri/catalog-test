import {Environment} from "./interface";

export const environment: Environment = {
  production: true,
  apiKey: "AIzaSyAKw1r0R7bXHcScGkLsBUDEX9CYXU4crRA",
  fbDbUrl: "https://test-app-df5b6-default-rtdb.firebaseio.com"
};
